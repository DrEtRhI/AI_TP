/**
 * Dessine un cible dans un canvas
 * @param {type} ctx le contexte graphique associé au canvas dans laquellle la cible est dessinée
 * @param {Number} x abscisse du centre de la cible
 * @param {Number} y ordonnée du centre de la cible
 * @param {Number} rExterne rayon externe de la cible 
 * @param {Number} rInterne rayon interne de la cible
 * @param {Number} nbCercles nombre de cercles dont la cible est composée
 */
function cible(ctx, x, y, rExterne, rInterne, nbCercles) {
    var deltaR = (rExterne - rInterne) / (nbCercles - 1);
    var r = rExterne;
    var color = "red";
    if (nbCercles % 2 === 0) {
        color = "yellow";
    }
    ctx.save();
    for (var i = 0; i < nbCercles; i++) {
        ctx.beginPath();
        ctx.arc(x, y, r, 0, 2 * Math.PI);
        ctx.fillStyle = color;
        ctx.fill();
        ctx.strokeStyle = "black";
        ctx.stroke();
        r = r - deltaR;
        if (color === "red") {
            color = "yellow";
        } else {
            color = "red";
        }
    }
    ctx.restore();
}


/**
 * fonction appelée au chargement de la page
 * (attribut onload de la balise body, cet événement a lieu une fois que 
 * la page est chargée et le DOM entièrement créé).
 */
function init() {

    // dessine 3 cibles dans le canvas1
    // à faire Q1

    // pavage dans le canvas2
    // à faire Q2

    // pavage alterné dans le canvas3
    // à faire Q3

    // pavage dans le canvas4 contrôlé par un slider et des radio boutons
    // à faire Q4

}


